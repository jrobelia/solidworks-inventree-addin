@echo off
:: Launch Install.ps1 as Administrator
PowerShell -NoProfile -ExecutionPolicy Bypass -Command "& { Start-Process PowerShell -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0Install.ps1""' -Verb RunAs -Wait }"
